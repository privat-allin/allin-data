# Optimus Prime Pack Installer
import requests,shutil, json, sys, os, xbmcgui, time, xbmc, urllib, urllib2, re, zipfile ,xbmcaddon ,xbmcplugin, xbmcvfs
from requests import get
from urllib2 import urlopen, Request
from sys import argv
from os import path, remove, makedirs
from xbmcgui import DialogProgress, Dialog, ListItem
from xbmcplugin import addDirectoryItem, endOfDirectory, setContent
from time import sleep
from kill import killxbmc
from xbmc import translatePath
from urllib import unquote_plus, quote_plus
from re import findall, compile
from zipfile import ZipFile
from xml.dom import minidom
from xbmcaddon import Addon
from json import loads
from shutil import rmtree
from distutils.version import StrictVersion

import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()

xonfluence =xbmc.translatePath(os.path.join('special://home','userdata','addon_data','xonfluence_wizard'))
phenomenal =xbmc.translatePath(os.path.join('special://home','userdata','addon_data','phenomenal_wizard'))
titan =xbmc.translatePath(os.path.join('special://home','userdata','addon_data','titan_wizard'))
basic =xbmc.translatePath(os.path.join('special://home','userdata','addon_data','basic_wizard'))
eminence =xbmc.translatePath(os.path.join('special://home','userdata','addon_data','eminence_wizard'))
nox =xbmc.translatePath(os.path.join('special://home','userdata','addon_data','nox_wizard'))


def deleteinstall():
    if os.path.exists(basic):
	 shutil.rmtree(basic)
    if os.path.exists(phenomenal):
	 shutil.rmtree(phenomenal)
    if os.path.exists(titan):
	 shutil.rmtree(titan)
    if os.path.exists(xonfluence):
	 shutil.rmtree(xonfluence)
    if os.path.exists(eminence):
	 shutil.rmtree(eminence)
    if os.path.exists(nox):
	 shutil.rmtree(nox)	 

def get_Kodi_Anabled():	 
    xbmc.executebuiltin('RunScript(special://home/addons/plugin.program.op.setup/skinAddon.py)')	 
	 

def DownloadNExtractZip(url,dest,name):
	dp = DialogProgress(); 
	dp.create(AddonName,"Downloading "+name,'','Please Wait')
	AddonFolder = path.join('special://','home','userdata','addon_data',addonID)
	tmpZip = translatePath(path.join(AddonFolder,"tmp.zip"))
	AddonFolder = translatePath(AddonFolder).decode("utf-8")
	if not path.exists(AddonFolder):
		makedirs(AddonFolder)
	else:
		try: remove(tmpZip)
		except: pass
	print "**** Optimus Prime-Wizard **** Downloading {0}".format(name)
	download_try=0
	while True:
		Download(url,tmpZip,dp)
		try:
			test_zip_file = ZipFile(tmpZip)
			ret = test_zip_file.testzip()
			if ret is None:
				break
		except:pass
		download_try += 1
		sleep(5)
		if download_try>4:
			if 'base' in path.basename(url):
				OKmsg(AddonName,"Error downloading pack from server","Try later again")
				sys.exit(1)
			print "**** Optimus Prime-Wizard **** Error Downloading {0} [{1}]".format(name,url)
			return 0
	print "**** Optimus Prime-Wizard **** Extracting {0}".format(name)
	dp.update(0,"Extracting Zip {0}".format(name),"",'Please Wait')
	Extract(tmpZip,dest,dp)
	
def AddonInstaller(id):
	global repo_addons
	print "*************** {0}".format(".".join(repo_addons))
	if id in repo_addons:
		url = repo_addons[id]
		local_filename = url.split('/')[-1]
	else:
		print "**** Optimus Prime-Wizard **** ERROR: {0} don't exist in Repo".format(id)
		return 0
	addonsFolder = translatePath(path.join('special://','home','addons'))
	if path.isdir(path.join(addonsFolder,id)) and 'skin' not in id:
		print "**** Optimus Prime-Wizard **** Skipping Exist {0} in Kodi".format(id)
		return 0
	DownloadNExtractZip(url,addonsFolder,id)
	try:
		depends = translatePath(path.join(addonsFolder,id,'addon.xml')); 
		source = open(depends,mode='r'); line=source.read(); source.close();
		regex =ur'import addon="(.+?)"'
		addon_requires = findall(regex, line)
		for addon_require in addon_requires:
			if not 'xbmc.' in addon_require:
				dependspath = translatePath(path.join('special://home','addons',addon_require))
				if not path.exists(dependspath): 
					AddonInstaller(addon_require)
	except: pass

def Download(source, target,dp = None):
	if not dp:
		dp = DialogProgress()
		dp.create("Status...","Checking Installation",' ', ' ')
	dp.update(0)
	r = get(source, stream=True, timeout=60)
	try:
		total_size = r.headers['content-length'].strip()
		total_size = int(total_size)
	except:
		return
	bytes_so_far = 0

	with open(target, 'wb') as fp:
		try:
			for chunk in r.iter_content(chunk_size=(1024*8)):
				if chunk:
					bytes_so_far += len(chunk)
					percent = min((100*bytes_so_far/total_size), 100)
					dp.update(percent)

					fp.write(chunk)

					if dp.iscanceled():
						raise Exception("Canceled")
						fp.close();	r.close(); dp.close()
						sys.exit(1)
		except:pass
	fp.close()
	r.close()
	return 1

def Extract(_in, _out, dp):
    zin = ZipFile(_in,  'r')
    nFiles = float(len(zin.infolist()))
    count  = 0

    try:
        for item in zin.infolist():
            count += 1
            update = count / nFiles * 100
            dp.update(int(update))
            zin.extract(item, translatePath(_out))
    except Exception, e:
        print str(e)
        return False

    return True
	
def GetRepoInfoc(repo,zipFolder):
	global repo_addons,repo_addons_version
	try:
		u1=urlopen(repo+"addons.xml")
		dom=minidom.parse(u1)
		addons = dom.getElementsByTagName("addon")
		for addon in addons:
			try:
				id = addon.getAttribute("id")
				version = addon.getAttribute("version")
				if (id not in repo_addons_version or (id in repo_addons_version and version>0 and StrictVersion(repo_addons_version[id]) < StrictVersion(version))):
					repo_addons_version[id] = version
					repo_addons[id] = repo+"/Zips/"+id+"/"+id+"-"+version+".zip"
			except:	pass
	except:	
		print "**** Optimus Prime-Wizard **** Error geting Repo XML {0}".format(repo)
	return 1
	
def GetRepoInfob(repo,zipFolder):
	global repo_addons,repo_addons_version
	try:
		u1=urlopen(repo+"addons.xml")
		dom=minidom.parse(u1)
		addons = dom.getElementsByTagName("addon")
		for addon in addons:
			try:
				id = addon.getAttribute("id")
				version = addon.getAttribute("version")
				if (id not in repo_addons_version or (id in repo_addons_version and version>0 and StrictVersion(repo_addons_version[id]) < StrictVersion(version))):
					repo_addons_version[id] = version
					repo_addons[id] = repo+"/repo/"+id+"/"+id+"-"+version+".zip"
			except:	pass
	except:	
		print "**** Optimus Prime-Wizard **** Error geting Repo XML {0}".format(repo)
	return 1
	
def GetRepoInfo(repo,zipFolder):
	global repo_addons,repo_addons_version
	try:
		u1=urlopen(repo+"addons.xml")
		dom=minidom.parse(u1)
		addons = dom.getElementsByTagName("addon")
		for addon in addons:
			try:
				id = addon.getAttribute("id")
				version = addon.getAttribute("version")
				if (id not in repo_addons_version or (id in repo_addons_version and version>0 and StrictVersion(repo_addons_version[id]) < StrictVersion(version))):
					repo_addons_version[id] = version
					repo_addons[id] = zipFolder+id+"/"+id+"-"+version+".zip"
			except:	pass
	except:	
		print "**** Optimus Prime-Wizard **** Error geting Repo XML {0}".format(repo)
	return 1
	
def OKmsg(title, line1, line2="", line3=""):
	Dialog().ok(title, line1, line2, line3)

def getParams(arg):
	param=[]
	paramstring=arg
	if len(paramstring)>=2:
		params=arg
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:    
				param[splitparams[0]]=splitparams[1]
							
	return param

def getParam(name,params):
	try:
		return unquote_plus(params[name])
	except:
		pass 

def addDir(name,id,action,iconimage,fanart,description):
	u=argv[0]+"?id="+str(id)+"&action="+str(action)
	liz=ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
	liz.setProperty( "Fanart_Image", fanart )
	ok=addDirectoryItem(handle=int(argv[1]),url=u,listitem=liz,isFolder=False)
	return ok
	
def setView(content, viewType):
	if content:	setContent(int(sys.argv[1]), content)
	xbmc.executebuiltin("Container.SetViewMode(%s)" % Addon.getSetting(viewType) )

def OpenURL(url):
	req = Request(url)
	req.add_header('Accept','text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8')      
	req.add_header('Cache-Control', 'max-age=0')
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36')
	response = urlopen(req)
	html = response.read()
	response.close()
	return html

def basicinstall():
   if os.path.exists(os.path.join(xbmc.translatePath("special://home/userdata/addon_data").decode("utf-8"), 'basic_wizard')):
    jsonSetFont = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"Arial"}, "id":1}'
    jsonSetsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.subtitlelanguage","value":"Hebrew"},"id":1}'
    jsonSetrss = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.enablerssfeeds","value":true}, "id":1}'
    jsonSetqewr = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.keyboardlayouts","value":["Hebrew QWERTY","English QWERTY"]},"id":1}'
    jsonSetlan = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.he_il"}, "id":1}'
    jsonSettorec = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.movie","value":"service.subtitles.opensubtitles_by_opensubtitles"},"id":1}'
    jsonSettorectv = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.tv","value":"service.subtitles.opensubtitles_by_opensubtitles"},"id":1}'
    jsonSethe = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":44},"id":1}'
    jsonSethebsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.languages","value":["Hebrew"]},"id":1}'

    if os.path.exists(xonfluence):
	 shutil.rmtree(xonfluence)
    if os.path.exists(phenomenal):
	 shutil.rmtree(phenomenal)
    if os.path.exists(titan):
	 shutil.rmtree(titan)
    if os.path.exists(eminence):
	 shutil.rmtree(eminence)
    if os.path.exists(nox):
	 shutil.rmtree(nox)		 
    time.sleep(5)	 
    get_Kodi_Anabled()
    time.sleep(7)	 
    xbmc.executeJSONRPC(jsonSetFont)
    xbmc.executeJSONRPC(jsonSetrss)
    xbmc.executeJSONRPC(jsonSetqewr)
    xbmc.executeJSONRPC(jsonSetlan)
    xbmc.executeJSONRPC(jsonSettorec)
    xbmc.executeJSONRPC(jsonSettorectv)
    xbmc.executeJSONRPC(jsonSethe)
    xbmc.executeJSONRPC(jsonSethebsub)
    xbmc.executebuiltin('XBMC.RefreshRSS') 
    xbmc.executeJSONRPC(jsonSetsub)
    xbmc.executebuiltin('UpdateLibrary(video)') 

def skinx():
  if (Skina == ['skin.xonfluence']):
    pass
  else:
    xbmc.executeJSONRPC(jsonSetskin % "skin.xonfluence")
	
	
def xonfluenceinstall():
   if os.path.exists(os.path.join(xbmc.translatePath("special://home/userdata/addon_data").decode("utf-8"), 'xonfluence_wizard')):
    if os.path.exists(basic):
	 shutil.rmtree(basic)
    if os.path.exists(phenomenal):
	 shutil.rmtree(phenomenal)
    if os.path.exists(titan):
	 shutil.rmtree(titan)
    if os.path.exists(eminence):
	 shutil.rmtree(eminence)
    if os.path.exists(nox):
	 shutil.rmtree(nox)		 

    time.sleep(5)	 
    get_Kodi_Anabled()
    time.sleep(7)	 
    jsonSetrss = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.enablerssfeeds","value":true}, "id":1}'
    jsonSetFont = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"Arial"}, "id":1}'
    jsonSetFontenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"default"}, "id":1}'
    jsonSetsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.subtitlelanguage","value":"Hebrew"},"id":1}'
    jsonSetsuben = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.subtitlelanguage","value":"English"},"id":1}'
    jsonSetqewr = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.keyboardlayouts","value":["Hebrew QWERTY","English QWERTY"]},"id":1}'
    jsonSetlan = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.he_il"}, "id":1}'
    jsonSetlanenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.en_gb"}, "id":1}'
    jsonSettorec = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.movie","value":"service.subtitles.opensubtitles_by_opensubtitles"},"id":1}'
    jsonSettorectv = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.tv","value":"service.subtitles.opensubtitles_by_opensubtitles"},"id":1}'
    jsonSethe = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":44},"id":1}'
    jsonSetfirst = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.downloadfirst","value":true},"id":1}'
    jsonSethebsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.languages","value":["Hebrew"]},"id":1}'
    jsonSetskin = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.xonfluence"}, "id":1}'
    jsonSetkrmm = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skincolors","value":"Kryptonite"}, "id":1}'
	 
    jsonSetlanenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.en_gb"}, "id":1}'
    jsonSetFontenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"default"}, "id":1}'
    xbmc.executeJSONRPC(jsonSetlanenglish)
    xbmc.executeJSONRPC(jsonSetFontenglish)
    time.sleep(1)
    xbmc.executeJSONRPC(jsonSetqewr)
    xbmc.executeJSONRPC(jsonSettorec)
    xbmc.executeJSONRPC(jsonSettorectv)
    xbmc.executeJSONRPC(jsonSetfirst)
    xbmc.executeJSONRPC(jsonSethe)
    xbmc.executeJSONRPC(jsonSethebsub)
    time.sleep(1)	
    xbmc.executebuiltin('XBMC.RefreshRSS')
    time.sleep(1)	
    xbmc.executebuiltin("ActivateWindow(10000)")
    time.sleep(5)	
    xbmc.executeJSONRPC(jsonSetskin)
    xbmc.executeJSONRPC(jsonSetlanenglish)
    xbmc.executeJSONRPC(jsonSetFontenglish)
    xbmc.executeJSONRPC(jsonSetskin)
    time.sleep(2)	
    xbmc.executeJSONRPC(jsonSetlanenglish)
    xbmc.executeJSONRPC(jsonSetFontenglish)
    xbmc.executeJSONRPC(jsonSetskin)
    time.sleep(2)	
    jsonSetlanenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.en_gb"}, "id":1}'
    jsonSetFontenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"default"}, "id":1}'
    xbmc.executeJSONRPC(jsonSetlanenglish)
    xbmc.executeJSONRPC(jsonSetFontenglish)	 	   
    xbmc.executeJSONRPC(jsonSetskin)
    xbmc.executeJSONRPC(jsonSetFont)
    xbmc.executeJSONRPC(jsonSetrss)
    time.sleep(1)
    xbmc.executeJSONRPC(jsonSetlan)
    xbmc.executeJSONRPC(jsonSetsub)
    time.sleep(5)
    xbmc.executeJSONRPC(jsonSetkrmm)
    xbmc.executebuiltin('XBMC.ReloadSkin()') 
    time.sleep(10)
    xbmc.executebuiltin('UpdateLibrary(video)') 

def phenomenalinstall():
   if os.path.exists(os.path.join(xbmc.translatePath("special://home/userdata/addon_data").decode("utf-8"), 'phenomenal_wizard')):
    if os.path.exists(basic):
	 shutil.rmtree(basic)
    if os.path.exists(xonfluence):
	 shutil.rmtree(xonfluence)
    if os.path.exists(titan):
	 shutil.rmtree(titan)
    if os.path.exists(eminence):
	 shutil.rmtree(eminence)
    if os.path.exists(nox):
	 shutil.rmtree(nox)		 
    time.sleep(5)	 
    get_Kodi_Anabled()
    time.sleep(7)	
    jsonSetFont = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"Arial"}, "id":1}'
    jsonSetsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.subtitlelanguage","value":"Hebrew"},"id":1}'
    jsonSetqewr = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.keyboardlayouts","value":["Hebrew QWERTY","English QWERTY"]},"id":1}'
    jsonSetlan = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.he_il"}, "id":1}'
    jsonSettorec = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.movie","value":"service.subtitles.thewiz"},"id":1}'
    jsonSettorectv = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.tv","value":"service.subtitles.thewiz"},"id":1}'
    jsonSetfirst = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.downloadfirst","value":true},"id":1}'
    jsonSethe = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":44},"id":1}'
    jsonSethebsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.languages","value":["Hebrew"]},"id":1}'
    jsonSetskin = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.phenomenal"}, "id":1}'
	

    xbmc.executeJSONRPC(jsonSetqewr)
    xbmc.executeJSONRPC(jsonSetlan)
    xbmc.executeJSONRPC(jsonSettorec)
    xbmc.executeJSONRPC(jsonSettorectv)
    xbmc.executeJSONRPC(jsonSetfirst)
    xbmc.executeJSONRPC(jsonSethe)
    xbmc.executeJSONRPC(jsonSethebsub)
    xbmc.executebuiltin('XBMC.RefreshRSS') 
    time.sleep(2)
    xbmc.executebuiltin("ActivateWindow(10000)")   
    time.sleep(5) 
    jsonSetlanenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.en_gb"}, "id":1}'
    jsonSetFontenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"default"}, "id":1}'
    xbmc.executeJSONRPC(jsonSetlanenglish)
    xbmc.executeJSONRPC(jsonSetFontenglish)	 		
    xbmc.executeJSONRPC(jsonSetskin)
    time.sleep(2)	
    xbmc.executeJSONRPC(jsonSetskin)
    time.sleep(2)	
    xbmc.executeJSONRPC(jsonSetskin) 
    time.sleep(2)	
    xbmc.executeJSONRPC(jsonSetlan)
    xbmc.executeJSONRPC(jsonSetFont)	
    xbmc.executebuiltin('XBMC.ReloadSkin()') 
    time.sleep(30)
    xbmc.executebuiltin('UpdateLibrary(video)') 

def eminenceinstall():
   if os.path.exists(os.path.join(xbmc.translatePath("special://home/userdata/addon_data").decode("utf-8"), 'eminence_wizard')):
    if os.path.exists(basic):
	 shutil.rmtree(basic)
    if os.path.exists(xonfluence):
	 shutil.rmtree(xonfluence)
    if os.path.exists(titan):
	 shutil.rmtree(titan)
    if os.path.exists(phenomenal):
	 shutil.rmtree(phenomenal)
    if os.path.exists(nox):
	 shutil.rmtree(nox)		 
    time.sleep(5)	 
    get_Kodi_Anabled()
    time.sleep(7)	
    jsonSetFont = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"Arial"}, "id":1}'
    jsonSetsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.subtitlelanguage","value":"Hebrew"},"id":1}'
    jsonSetqewr = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.keyboardlayouts","value":["Hebrew QWERTY","English QWERTY"]},"id":1}'
    jsonSetlan = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.he_il"}, "id":1}'
    jsonSettorec = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.movie","value":"service.subtitles.thewiz"},"id":1}'
    jsonSettorectv = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.tv","value":"service.subtitles.thewiz"},"id":1}'
    jsonSetfirst = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.downloadfirst","value":true},"id":1}'
    jsonSethe = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":44},"id":1}'
    jsonSethebsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.languages","value":["Hebrew"]},"id":1}'
    jsonSetskin = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.eminence.2.mod"}, "id":1}'
	

    xbmc.executeJSONRPC(jsonSetqewr)
    xbmc.executeJSONRPC(jsonSetlan)
    xbmc.executeJSONRPC(jsonSettorec)
    xbmc.executeJSONRPC(jsonSettorectv)
    xbmc.executeJSONRPC(jsonSetfirst)
    xbmc.executeJSONRPC(jsonSethe)
    xbmc.executeJSONRPC(jsonSethebsub)
    xbmc.executebuiltin('XBMC.RefreshRSS') 
    time.sleep(2)
    xbmc.executebuiltin("ActivateWindow(10000)")   
    time.sleep(5) 
    jsonSetlanenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.en_gb"}, "id":1}'
    jsonSetFontenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"default"}, "id":1}'
    xbmc.executeJSONRPC(jsonSetlanenglish)
    xbmc.executeJSONRPC(jsonSetFontenglish)	 		
    xbmc.executeJSONRPC(jsonSetskin)
    time.sleep(2)	
    xbmc.executeJSONRPC(jsonSetskin)
    time.sleep(2)	
    xbmc.executeJSONRPC(jsonSetskin) 
    time.sleep(2)	
    xbmc.executeJSONRPC(jsonSetlan)
    xbmc.executeJSONRPC(jsonSetFont)	
    xbmc.executebuiltin('XBMC.ReloadSkin()') 
    time.sleep(30)
    xbmc.executebuiltin('UpdateLibrary(video)') 	
	
def titaninstall():
   if os.path.exists(os.path.join(xbmc.translatePath("special://home/userdata/addon_data").decode("utf-8"), 'titan_wizard')):
    if os.path.exists(basic):
	 shutil.rmtree(basic)
    if os.path.exists(xonfluence):
	 shutil.rmtree(xonfluence)
    if os.path.exists(phenomenal):
	 shutil.rmtree(phenomenal)	
    if os.path.exists(eminence):
	 shutil.rmtree(eminence)
    if os.path.exists(nox):
	 shutil.rmtree(nox)		 

    time.sleep(5)	 
    get_Kodi_Anabled()
    time.sleep(7)	 
    jsonSetrss = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.enablerssfeeds","value":true}, "id":1}'
    jsonSetFont = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"Arial"}, "id":1}'
    jsonSetsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.subtitlelanguage","value":"Hebrew"},"id":1}'
    jsonSetqewr = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.keyboardlayouts","value":["Hebrew QWERTY","English QWERTY"]},"id":1}'
    jsonSetlan = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.he_il"}, "id":1}'
    jsonSettorec = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.movie","value":"service.subtitles.thewiz"},"id":1}'
    jsonSettorectv = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.tv","value":"service.subtitles.thewiz"},"id":1}'
    jsonSetfirst = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.downloadfirst","value":true},"id":1}'
    jsonSethe = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":44},"id":1}'
    jsonSethebsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.languages","value":["Hebrew"]},"id":1}'
    jsonSetlanenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.en_gb"}, "id":1}'
    jsonSetFontenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"default"}, "id":1}'
    jsonSetskin = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.titan.hebmod"}, "id":1}'

    time.sleep(2)
    xbmc.executeJSONRPC(jsonSetsub)
    xbmc.executeJSONRPC(jsonSetFont)
    xbmc.executeJSONRPC(jsonSetrss)
    time.sleep(1)
    xbmc.executeJSONRPC(jsonSetqewr)
    xbmc.executeJSONRPC(jsonSetlan)
    xbmc.executeJSONRPC(jsonSettorec)
    xbmc.executeJSONRPC(jsonSettorectv)
    xbmc.executeJSONRPC(jsonSetfirst)
    xbmc.executeJSONRPC(jsonSethe)
    xbmc.executeJSONRPC(jsonSethebsub)
    xbmc.executebuiltin('XBMC.RefreshRSS')
    time.sleep(2)
    xbmc.executebuiltin("ActivateWindow(10000)")   
    time.sleep(5)   
    xbmc.executeJSONRPC(jsonSetlanenglish)
    xbmc.executeJSONRPC(jsonSetFontenglish)	 
    xbmc.executeJSONRPC(jsonSetskin)
    time.sleep(2)
    jsonSetlanenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.en_gb"}, "id":1}'
    jsonSetFontenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"default"}, "id":1}'
    xbmc.executeJSONRPC(jsonSetlanenglish)
    xbmc.executeJSONRPC(jsonSetFontenglish)	 
    xbmc.executeJSONRPC(jsonSetskin)
    time.sleep(5)
    jsonSetlanenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.en_gb"}, "id":1}'
    jsonSetFontenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"default"}, "id":1}'
    xbmc.executeJSONRPC(jsonSetlanenglish)
    xbmc.executeJSONRPC(jsonSetFontenglish)	 
    xbmc.executeJSONRPC(jsonSetskin) 
    time.sleep(5)
    xbmc.executeJSONRPC(jsonSetlan)
    xbmc.executeJSONRPC(jsonSetFont)
    time.sleep(5)
    xbmc.executebuiltin('XBMC.ReloadSkin()') 
    time.sleep(15)
    xbmc.executebuiltin('UpdateLibrary(video)') 

def noxinstall():
   if os.path.exists(os.path.join(xbmc.translatePath("special://home/userdata/addon_data").decode("utf-8"), 'nox_wizard')):
    if os.path.exists(basic):
	 shutil.rmtree(basic)
    if os.path.exists(xonfluence):
	 shutil.rmtree(xonfluence)
    if os.path.exists(phenomenal):
	 shutil.rmtree(phenomenal)	
    if os.path.exists(eminence):
	 shutil.rmtree(eminence)
    if os.path.exists(titan):
	 shutil.rmtree(titan)		 

    time.sleep(5)	 
    get_Kodi_Anabled()
    time.sleep(7)	 
    jsonSetrss = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.enablerssfeeds","value":true}, "id":1}'
    jsonSetFont = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"Arial"}, "id":1}'
    jsonSetsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.subtitlelanguage","value":"Hebrew"},"id":1}'
    jsonSetqewr = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.keyboardlayouts","value":["Hebrew QWERTY","English QWERTY"]},"id":1}'
    jsonSetlan = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.he_il"}, "id":1}'
    jsonSettorec = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.movie","value":"service.subtitles.thewiz"},"id":1}'
    jsonSettorectv = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.tv","value":"service.subtitles.thewiz"},"id":1}'
    jsonSetfirst = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.downloadfirst","value":true},"id":1}'
    jsonSethe = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.height","value":44},"id":1}'
    jsonSethebsub = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"subtitles.languages","value":["Hebrew"]},"id":1}'
    jsonSetlanenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.en_gb"}, "id":1}'
    jsonSetFontenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"default"}, "id":1}'
    jsonSetskin = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.skin","value":"skin.aeon.nox.5"}, "id":1}'

    time.sleep(2)
    xbmc.executeJSONRPC(jsonSetsub)
    xbmc.executeJSONRPC(jsonSetFont)
    xbmc.executeJSONRPC(jsonSetrss)
    time.sleep(1)
    xbmc.executeJSONRPC(jsonSetqewr)
    xbmc.executeJSONRPC(jsonSetlan)
    xbmc.executeJSONRPC(jsonSettorec)
    xbmc.executeJSONRPC(jsonSettorectv)
    xbmc.executeJSONRPC(jsonSetfirst)
    xbmc.executeJSONRPC(jsonSethe)
    xbmc.executeJSONRPC(jsonSethebsub)
    xbmc.executebuiltin('XBMC.RefreshRSS')
    time.sleep(2)
    xbmc.executebuiltin("ActivateWindow(10000)")   
    time.sleep(5)   
    xbmc.executeJSONRPC(jsonSetlanenglish)
    xbmc.executeJSONRPC(jsonSetFontenglish)	 
    xbmc.executeJSONRPC(jsonSetskin)
    time.sleep(2)
    jsonSetlanenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.en_gb"}, "id":1}'
    jsonSetFontenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"default"}, "id":1}'
    xbmc.executeJSONRPC(jsonSetlanenglish)
    xbmc.executeJSONRPC(jsonSetFontenglish)	 
    xbmc.executeJSONRPC(jsonSetskin)
    time.sleep(5)
    jsonSetlanenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"locale.language","value":"resource.language.en_gb"}, "id":1}'
    jsonSetFontenglish = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":"lookandfeel.font","value":"default"}, "id":1}'
    xbmc.executeJSONRPC(jsonSetlanenglish)
    xbmc.executeJSONRPC(jsonSetFontenglish)	 
    xbmc.executeJSONRPC(jsonSetskin) 
    time.sleep(5)
    xbmc.executeJSONRPC(jsonSetlan)
    xbmc.executeJSONRPC(jsonSetFont)
    time.sleep(5)
    xbmc.executebuiltin('XBMC.ReloadSkin()') 
    time.sleep(15)
    xbmc.executebuiltin('UpdateLibrary(video)') 	

def updateinstall():
	dialog = Dialog()
	dialog.ok("Optimus Prime Kodi Setup", 'update successful', '', '')	
		 
	
global repo_addons,repo_addons_version, AddonName
addonID = "plugin.program.op.setup"
Addon = Addon(addonID)
AddonName = Addon.getAddonInfo("name")

repo_addons = {}
repo_addons_version = {}

deleteinstall()

PackVer = OpenURL("https://github.com/privat-allin/allin-data/raw/master/server_data/pack.version.txt")
lastUpdateFile = translatePath(path.join('special://','home','userdata','addon_data',addonID,PackVer+'.txt'))
packFile = translatePath(path.join('special://','home','userdata','addon_data',addonID,'pack.txt'))
print "**** Optimus Prime-Wizard **** Server Ver:{0}".format(PackVer)
if path.isfile(lastUpdateFile): sys.exit(1)

localizedString = Addon.getLocalizedString 

packs = OpenURL("https://github.com/privat-allin/allin-data/raw/master/server_data/packs.json")
json = loads(packs)

action=None
if len(argv) >= 2:   
	params = getParams(argv[2])
	action = getParam("action", params)

print "**** Optimus Prime-Wizard **** Action:{0}".format(action)
if action==None:
	for packs in json:
		addDir(packs['name'],packs['id'],"download",packs['img'],packs['fanart'],packs['description'])
	setView('movies', 'MAIN')
elif action=="download" or action=="update":
	if action=="update":
		if not path.isfile(packFile):
			sys.exit(1)
		file = open(packFile, 'r')
		id = file.read()
	else:
		id = getParam("id", params)
	for packs in json:
		if packs['id'] == id:
			pack = packs
	if 'addons' in pack:
		xbmc.executebuiltin('Notification({0}, Getting all repo new addons. Wait for it..., {1})'.format(AddonName, 25000))	
		GetRepoInfo("http://mirror.nl.leaseweb.net/xbmc/addons/krypton/","http://mirror.nl.leaseweb.net/xbmc/addons/krypton/")
		GetRepoInfo("https://raw.githubusercontent.com/Apollo2000/Repo/master/","https://raw.githubusercontent.com/Apollo2000/Repo/master/")		
		GetRepoInfob("https://raw.githubusercontent.com/kodil/kodil/master/","https://raw.githubusercontent.com/kodil/kodil/master/")
		GetRepoInfoc("https://raw.githubusercontent.com/privat-allin/all-in/master/","https://raw.githubusercontent.com/privat-allin/all-in/master/")

	if 'zip' in pack:
		zips = pack['zip']
		for zip in zips:
			zip = zip.replace('[VER]',PackVer)
			print "**** Optimus Prime-Wizard **** ZIP {0}".format(zip)
			DownloadNExtractZip(zip,'special://home',path.basename(zip))
	if 'addons' in pack:
		addons = pack['addons']
		for addon in addons:
			print "**** Optimus Prime-Wizard **** ADDON {0}".format(addon)
			AddonInstaller(addon)
	time.sleep(10)
	get_Kodi_Anabled()
	time.sleep(5)
	basicinstall()
	phenomenalinstall()
	xonfluenceinstall()
	titaninstall()
	eminenceinstall()
	noxinstall()
	
	if pack['name'] == 'update':
		updateinstall()
	if pack['name'] == 'basic':
		basicinstall()
	if pack['name'] == 'phenomenal':
		phenomenalinstall()
	if pack['name'] == 'xonfluence':
		xonfluenceinstall()
	if pack['name'] == 'eminence':
		eminence
	if pack['name'] == 'nox':
		noxinstall()
	if pack['name'] == 'anonymous':
		killxbmc()		
	
		


endOfDirectory(int(sys.argv[1]))